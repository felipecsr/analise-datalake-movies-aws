import os
import json
import requests
import logging
import boto3
from datetime import datetime
from botocore.exceptions import NoCredentialsError

# Configuração de logs
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Cliente do S3
s3 = boto3.client('s3')

def fetch_movie_details(movie_id, tmdb_api_key):
    """Busca os detalhes de um filme específico usando o ID."""
    url = f"https://api.themoviedb.org/3/movie/{movie_id}"
    params = {"api_key": tmdb_api_key}
    response = requests.get(url, params=params)
    response.raise_for_status()
    return response.json()

def fetch_movies_by_decade(genre_id, start_year, tmdb_api_key, max_pages=500, max_records=100):
    """Busca filmes por gênero e década."""
    base_url = "https://api.themoviedb.org/3/discover/movie"
    all_movies = []
    end_year = start_year + 9
    page = 1

    while True:
        params = {
            "with_genres": genre_id,
            "primary_release_date.gte": f"{start_year}-01-01",
            "primary_release_date.lte": f"{end_year}-12-31",
            "page": page,
            "api_key": tmdb_api_key
        }
        try:
            logging.info(f"Buscando filmes - Gênero: {genre_id}, Década: {start_year}-{end_year}, Página: {page}")
            response = requests.get(base_url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            movies = data.get("results", [])
            if not movies or len(all_movies) >= max_records:
                break
            for movie in movies:
                movie_details = fetch_movie_details(movie["id"], tmdb_api_key)
                all_movies.append(movie_details)
                if len(all_movies) >= max_records:
                    break
            page += 1
            if page > max_pages:
                break
        except requests.exceptions.RequestException as e:
            logging.error(f"Erro ao buscar filmes: {e}")
            break
    return all_movies

def save_to_s3(bucket_name, folder_path, filename, data):
    """Salva o JSON no S3."""
    file_path = f"{folder_path}/{filename}"
    try:
        s3.put_object(Bucket=bucket_name, Key=file_path, Body=json.dumps(data, ensure_ascii=False, indent=4))
        logging.info(f"Arquivo salvo no S3: s3://{bucket_name}/{file_path}")
    except NoCredentialsError:
        logging.error("Credenciais AWS não configuradas corretamente.")
    except Exception as e:
        logging.error(f"Erro ao salvar arquivo no S3: {e}")

def lambda_handler(event, context):
    """Handler principal do AWS Lambda."""
    tmdb_api_key = os.getenv("TMDB_API_KEY")
    bucket_name = "desafio-filmes-series"
    base_path = f"Raw/TMDB/JSON/Movies/{datetime.now().strftime('%Y/%m/%d')}"

    genres = {
        "Crime": {"id": 80},
        "Guerra": {"id": 10752}
    }
    start_year = int(event["start_year"])  # Recebido pelo evento
    end_year = start_year + 9

    for genre_name, genre_data in genres.items():
        genre_id = genre_data["id"]
        movies = fetch_movies_by_decade(genre_id, start_year, tmdb_api_key)
        batch_number = 1
        for i in range(0, len(movies), 100):
            chunk = movies[i:i + 100]
            filename = f"{genre_name.lower()}-{start_year}-{end_year}-{batch_number}.json"
            save_to_s3(bucket_name, base_path, filename, chunk)
            batch_number += 1
    logging.info("Processo concluído com sucesso.")
